$(document).ready(function(){

    $('#slides').superslides({
        animation: 'fade',
        play:5000
    });
});

